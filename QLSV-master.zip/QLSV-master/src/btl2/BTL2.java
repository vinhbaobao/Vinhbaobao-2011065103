
package btl2;


public class BTL2 {

    
    public static void main(String[] args) {
        new Login().setVisible(true);
    }
    
}
