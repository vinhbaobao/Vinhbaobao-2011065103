/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package qlsvtest;

import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author Thanh
 */
public class GiangVienModel extends DefaultComboBoxModel<GiangVienM> {

    public GiangVienModel(GiangVienM[] items) {
        super(items);
    }
}
