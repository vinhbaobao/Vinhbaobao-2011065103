/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package qlsvtest;

import java.math.BigInteger;
import java.util.BitSet;

/**
 *
 * @author Thanh
 */
public class GiangVienM {

    public BigInteger getId() {
        return id;
    }

    public void setId(BigInteger id) {
        this.id = id;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public BitSet getIs_delete() {
        return is_delete;
    }

    public void setIs_delete(BitSet is_delete) {
        this.is_delete = is_delete;
    }

    public GiangVienM(BigInteger id, String ten, String ma, BitSet is_delete) {
        this.id = id;
        this.ten = ten;
        this.ma = ma;
        this.is_delete = is_delete;
    }
    private BigInteger id;
    private String ten;
    private String ma;
    private BitSet is_delete;
}
