/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package qlsvtest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Thanh
 */
public class Diem extends javax.swing.JFrame {

    Vector vctHeader = new Vector();

    Vector vctData = new Vector();

    ArrayList<String> sinhvien = new ArrayList<String>();

    ArrayList<String> monhoc = new ArrayList<String>();

    private Connection conn;

    int index = -1;

    /**
     * Creates new form Lop
     */
    public Diem() {
        initComponents();

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=QLSV;user=sa;password=12345678");
        } catch (Exception e) {
            System.out.println(e);
        }

        vctHeader.add("Id");
        vctHeader.add("Mã Sinh Viên");
        vctHeader.add("Mã Môn Học");
        vctHeader.add("Điểm Giữa Kỳ");
        vctHeader.add("Điểm Cuối Kỳ");
        vctHeader.add("Điểm Chuyên Cần");

        loadDbToTable();

        loadDbtoList();
    }

    public void loadDbtoList() {
        try {
            sinhvien.add("Toàn bộ");
            monhoc.add("Toàn bộ");

            Statement st = conn.createStatement();
            ResultSet rs2 = st.executeQuery("SELECT * FROM sinhvien");

            while (rs2.next()) {
                sinhvien.add(rs2.getString(3));

            }

            ResultSet rs1 = st.executeQuery("SELECT * FROM monhoc");
            while (rs1.next()) {
                monhoc.add(rs1.getString(3));

            }
            jComboBox2.setModel(new DefaultComboBoxModel(sinhvien.toArray(String[]::new)));
            jComboBox1.setModel(new DefaultComboBoxModel(monhoc.toArray(String[]::new)));

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void loadDbToTable() {
        vctData = new Vector();
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM diem");
            while (rs.next()) {
                Vector vctRow = new Vector();
                vctRow.add(rs.getString(1).trim());
                vctRow.add(rs.getString(3).trim());
                vctRow.add(rs.getString(2).trim());
                vctRow.add(rs.getString(4).trim());
                vctRow.add(rs.getString(5).trim());
                vctRow.add(rs.getString(6).trim());

                vctData.add(vctRow);
            }
            jTable1.setModel(new DefaultTableModel(vctData, vctHeader));
            index = -1;

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void displayDetails(int selectedIndex) {

        int s1 = -1;
        int s2 = -1;

        Vector vctSelectedRow = (Vector) vctData.get(selectedIndex);

        String giuaky = (String) vctSelectedRow.get(3);

        String cuoiky = (String) vctSelectedRow.get(4);

        String chuyencan = (String) vctSelectedRow.get(5);

        //int pcpc = khoa.indexOf(vctSelectedRow.get(2).toString().trim());
        jTFGK.setText(giuaky.trim());

        jTFCK.setText(cuoiky.trim());

        jTFCC.setText(chuyencan.trim());

        for (int i = 0; i < sinhvien.size(); i++) {
            System.out.println(i);
            System.out.println(sinhvien.get(i).toString());
            System.out.println(vctSelectedRow.get(1).toString().trim());

            System.out.println("--------");
            if (sinhvien.get(i).toString().trim().equals(vctSelectedRow.get(1).toString().trim())) {
                s1 = i;
                System.out.println("true");
                break;
            }
        }

        for (int i = 0; i < monhoc.size(); i++) {
            /*  System.out.println(i);
            System.out.println(monhoc.get(i).toString());
            System.out.println(vctSelectedRow.get(1).toString().trim());*/

            //   System.out.println("--------");
            if (monhoc.get(i).toString().trim().equals(vctSelectedRow.get(2).toString().trim())) {
                s2 = i;
                //      System.out.println("true");
                break;
            }
        }
        // System.out.println(s1);

        jComboBox1.setSelectedIndex(s2);

        jComboBox2.setSelectedIndex(s1);

        //System.out.println(pcpc);
        //  System.out.println((String) vctSelectedRow.get(2));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jTFGK = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jBThem = new javax.swing.JButton();
        jBXoa = new javax.swing.JButton();
        jBSua = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jBTim = new javax.swing.JButton();
        jComboBox2 = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jTFCK = new javax.swing.JTextField();
        jTFCC = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                formKeyReleased(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTable1KeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel1.setText("Giữa Kỳ");

        jBThem.setText("Thêm");
        jBThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBThemActionPerformed(evt);
            }
        });

        jBXoa.setText("Xóa");
        jBXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBXoaActionPerformed(evt);
            }
        });

        jBSua.setText("Sửa");
        jBSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBSuaActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 60)); // NOI18N
        jLabel2.setText("ĐIỂM");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel3.setText("Mã Môn Học");

        jBTim.setText("Tìm");
        jBTim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBTimActionPerformed(evt);
            }
        });

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel4.setText("Mã Sinh Viên");

        jLabel5.setText("Cuối Kỳ");

        jLabel6.setText("Chuyên Cần");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 788, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(77, 77, 77)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel6))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jTFCC, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jTFGK, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jTFCK, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(114, 114, 114)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jBSua, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jBXoa, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jBTim, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jBThem, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTFCC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTFGK, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTFCK, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jBThem)
                        .addGap(18, 18, 18)
                        .addComponent(jBXoa)
                        .addGap(18, 18, 18)
                        .addComponent(jBSua)
                        .addGap(18, 18, 18)
                        .addComponent(jBTim)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 73, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_formKeyReleased

    private void jTable1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyReleased
        int selectedRow = jTable1.getSelectedRow();
        index = selectedRow;
        displayDetails(selectedRow);
    }//GEN-LAST:event_jTable1KeyReleased

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        int selectedRow = jTable1.getSelectedRow();
        index = selectedRow;
        displayDetails(selectedRow);
    }//GEN-LAST:event_jTable1MouseClicked

    private void jBThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBThemActionPerformed
        // TODO add your handling code here:

        try {
            String sql = "INSERT INTO diem (monhocma, sinhvienma,giuaky,cuoiky,chuyencan) VALUES (?,?,?,?,?);";
            PreparedStatement ps = conn.prepareStatement(sql.trim());
            ps.setString(1, jComboBox1.getSelectedItem().toString());
            ps.setString(2, jComboBox2.getSelectedItem().toString());
            ps.setString(3, jTFGK.getText().trim());
            ps.setString(4, jTFCK.getText().trim());
            ps.setString(5, jTFCC.getText().trim());

            ps.executeUpdate();

            jTFGK.setText("");
            jTFCK.setText("");
            jTFCC.setText("");

            jComboBox1.setSelectedIndex(0);

            jComboBox2.setSelectedIndex(0);
            loadDbToTable();

        } catch (Exception e) {
            System.out.println(e);
        }

    }//GEN-LAST:event_jBThemActionPerformed

    private void jBXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBXoaActionPerformed
        // TODO add your handling code here:

        try {

            Vector vctSelectedRow = (Vector) vctData.get(index);
            String id = (String) vctSelectedRow.get(0);

            String sql = "DELETE FROM diem WHERE id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ps.executeUpdate();

            jTFGK.setText("");
            loadDbToTable();

        } catch (Exception e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_jBXoaActionPerformed

    private void jBSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBSuaActionPerformed
        // TODO add your handling code here:

        try {

            Vector vctSelectedRow = (Vector) vctData.get(index);
            String id = (String) vctSelectedRow.get(0);
            String giuaky = jTFGK.getText();
            String cuoiky = jTFCK.getText();
            String chuyencan = jTFCC.getText();

            String sql = "UPDATE diem SET monhocma = ?, sinhvienma = ?,giuaky = ?, cuoiky = ?, chuyencan = ? WHERE id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, jComboBox1.getSelectedItem().toString().trim());
            ps.setString(5, id.trim());
            ps.setString(2, jComboBox2.getSelectedItem().toString().trim());
            ps.setString(3, giuaky.trim());
            ps.setString(4, cuoiky.trim());
            ps.setString(4, chuyencan.trim());

            ps.executeUpdate();

            jTFGK.setText("");
            jTFCK.setText("");
                   jTFCC.setText("");
            jComboBox1.setSelectedIndex(0);
            jComboBox2.setSelectedIndex(0);
            loadDbToTable();

        } catch (Exception e) {
            System.out.println(e);
        }

    }//GEN-LAST:event_jBSuaActionPerformed

    private void jBTimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBTimActionPerformed
        // TODO add your handling code here:
        vctData = new Vector();
        try {
            Statement st = conn.createStatement();
            String lop = jTFGK.getText().trim();
            String sql = "SELECT * FROM lop " + sqlTim();
            PreparedStatement ps = conn.prepareStatement(sql);
            //ps.setString(1, "07");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Vector vctRow = new Vector();
                vctRow.add(rs.getString(1));
                vctRow.add(rs.getString(2));
                vctRow.add(rs.getString(3));

                vctData.add(vctRow);
            }
            jTable1.setModel(new DefaultTableModel(vctData, vctHeader));
            index = -1;

        } catch (Exception e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_jBTimActionPerformed
    public String sqlTim() {
        String rs = "";
        int i = 1;
        if (jTFGK.getText().trim() != "" || jComboBox1.getSelectedItem().toString() != "Toàn bộ") {
            rs += " WHERE ";
        }
        if (jTFGK.getText().trim() != "" && jComboBox1.getSelectedItem().toString() != "Toàn bộ") {
            i = 2;
        }
        if (jTFGK.getText().trim() != "") {
            rs += "ten like '%" + jTFGK.getText().trim() + "%'";
        }
        if (i == 2) {
            rs += " and ";
        }
        if (jComboBox1.getSelectedItem().toString() != "Toàn bộ") {
            rs += "khoa = '" + jComboBox1.getSelectedItem().toString().trim() + "'";
        }
        rs += ";";

        System.out.println(rs);
        System.out.println("AAAAA");
        return rs.trim();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Diem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Diem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Diem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Diem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Diem().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBSua;
    private javax.swing.JButton jBThem;
    private javax.swing.JButton jBTim;
    private javax.swing.JButton jBXoa;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTFCC;
    private javax.swing.JTextField jTFCK;
    private javax.swing.JTextField jTFGK;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
